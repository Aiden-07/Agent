﻿// Agent Management Logic

// Mock Data
let agentsData = [];
const MODELS = ['GPT-4o', 'Claude 3.5 Sonnet', 'GPT-4 Turbo', 'DeepSeek V2'];
const KBS = ['产品文档库', '技术规范', '员工手册', '市场分析报告'];
const CREATORS = ['Admin', 'User_1001', 'User_1002', 'User_1003'];

// Realistic Agent Names
const AGENT_NAMES = [
    '电商客服助手', 'Python 代码审查员', '英文翻译专家', 'SQL 查询生成器', 
    '周报自动生成助手', '产品文案润色', '旅游行程规划师', '法律咨询顾问', 
    '前端组件生成器', '招聘简历筛选助手', '数据分析报告生成', 'API 文档自动生成',
    '用户评论情感分析', '智能会议纪要', '个性化推荐引擎'
];

// Mock MCP and Plugin Data
let mcpData = [
    { id: 'MCP-001', name: 'Google Search' },
    { id: 'MCP-002', name: 'GitHub Integration' },
    { id: 'MCP-003', name: 'Slack Notifier' },
    { id: 'MCP-004', name: 'Linear Issue Tracker' },
    { id: 'MCP-005', name: 'Postgres Database' }
];

let pluginData = [
    { id: 'PLG-001', name: 'Code Interpreter' },
    { id: 'PLG-002', name: 'Image Generator' },
    { id: 'PLG-003', name: 'PDF Reader' },
    { id: 'PLG-004', name: 'Wolfram Alpha' },
    { id: 'PLG-005', name: 'Web Browser' }
];

let currentPage = 1;
const pageSize = 10;
let isLoading = false;
let hasMore = true;
let currentSearch = '';
let currentFilter = 'all';

// Generate initial mock data
function generateMockAgents(count) {
    const newAgents = [];
    for (let i = 0; i < count; i++) {
        const id = window.generateId ? window.generateId('AGT') : `AGT-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
        // Pick a name from the list cyclically or randomly
        let name;
        if (i < AGENT_NAMES.length) {
             name = AGENT_NAMES[i % AGENT_NAMES.length];
        } else {
             name = `${AGENT_NAMES[i % AGENT_NAMES.length]} ${Math.floor(i / AGENT_NAMES.length) + 1}`;
        }

        const createdAtDate = new Date(Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000));
        
        newAgents.push({
            id: id,
            name: name,
            model: MODELS[Math.floor(Math.random() * MODELS.length)],
            // Generate random multiple knowledge bases (1-3)
            knowledgeBase: (() => {
                const shuffled = [...KBS].sort(() => 0.5 - Math.random());
                const count = Math.floor(Math.random() * 3) + 1; // 1 to 3
                return shuffled.slice(0, count);
            })(),
            creator: CREATORS[Math.floor(Math.random() * CREATORS.length)],
            createdAt: createdAtDate.toLocaleString(),
            timestamp: createdAtDate.getTime(), // Added for sorting
            updatedAt: new Date(createdAtDate.getTime() + Math.floor(Math.random() * 10 * 24 * 60 * 60 * 1000)).toLocaleString(),
            hot: Math.floor(Math.random() * 10000),
            status: Math.random() > 0.2 ? 'running' : 'stopped' // 80% running
        });
    }
    return newAgents;
}

// Initialize
function initAgentPage() {
    console.log('Initializing Agent Page...');
    
    // Reset state if needed, or keep it to persist during session
    // For now, let's check if we already have data, if not generate some
    if (agentsData.length === 0) {
        agentsData = generateMockAgents(10); // Changed from 25 to 10
    }
    
    // Reset view state
    currentPage = 1;
    hasMore = true;
    isLoading = false;
    currentSearch = ''; // Optional: Reset filters on re-entry
    currentFilter = 'all';

    // Render initial list
    renderAgentList(true);
    updateStats();
    
    // Bind Events
    const scrollContainer = document.getElementById('agent-list-container');
    if (scrollContainer) {
        scrollContainer.addEventListener('scroll', handleScroll);
    }

    const searchInput = document.getElementById('agent-search-input');
    if (searchInput) {
        searchInput.value = ''; // Clear input visually
        searchInput.addEventListener('input', (e) => {
            currentSearch = e.target.value.toLowerCase();
            currentPage = 1;
            hasMore = true;
            renderAgentList(true);
        });
    }

    const statusFilter = document.getElementById('agent-status-filter');
    if (statusFilter) {
        statusFilter.value = 'all'; // Reset select visually
        statusFilter.addEventListener('change', (e) => {
            currentFilter = e.target.value;
            currentPage = 1;
            hasMore = true;
            renderAgentList(true);
        });
    }
}

function handleScroll(e) {
    const { scrollTop, scrollHeight, clientHeight } = e.target;
    
    // Check if scrolled near bottom
    if (scrollHeight - scrollTop <= clientHeight + 50) {
        if (!isLoading && hasMore) {
            loadMoreAgents();
        }
    }
}

function loadMoreAgents() {
    isLoading = true;
    const loader = document.getElementById('agent-list-loader');
    if (loader) loader.classList.remove('hidden');

    // Simulate network delay
    setTimeout(() => {
        currentPage++;
        
        // Let's generate 5 more "new" items to simulate infinite DB if we run out of mock data?
        // Or just pretend existing data is paginated.
        // For true infinite scroll feel in prototype, let's generate more data if we reach the end of static list.
        // But logic is simpler if we just filter existing data. 
        // Let's create more data on the fly to append to `agentsData` so the list grows.
        
        const newItems = generateMockAgents(5); 
        agentsData = [...agentsData, ...newItems]; // Append to master list
        
        renderAgentList(false); // Append/Re-render
        
        isLoading = false;
        if (loader) loader.classList.add('hidden');
    }, 800);
}

function getFilteredAgents() {
    let filtered = agentsData.filter(agent => {
        const matchesSearch = agent.name.toLowerCase().includes(currentSearch) || 
                              agent.id.toString().includes(currentSearch);
        const matchesStatus = currentFilter === 'all' || agent.status === currentFilter;
        return matchesSearch && matchesStatus;
    });
    // Sort by timestamp desc (newest first)
    return filtered.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
}

function renderAgentList(reset = false) {
    const tbody = document.getElementById('agent-list-body');
    const emptyState = document.getElementById('agent-list-empty');
    if (!tbody) return;

    const allFiltered = getFilteredAgents();
    const visibleCount = currentPage * pageSize;
    const visibleAgents = allFiltered.slice(0, visibleCount);
    
    // If we have fewer items than we want to show (and no search active), maybe trigger loadMore?
    // But simplified logic: just show what we have in `visibleAgents`.

    if (reset) {
        tbody.innerHTML = '';
    } else {
        // Optimization: could just append new ones, but re-render is safer for sort/filter consistency
        tbody.innerHTML = ''; 
    }

    if (visibleAgents.length === 0) {
        if (emptyState) emptyState.classList.remove('hidden');
    } else {
        if (emptyState) emptyState.classList.add('hidden');
        
        visibleAgents.forEach((agent, index) => {
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-gray-50 transition-colors group';
            
            // Calculate global index (optional, but requested "序号")
            // Since visibleAgents starts from 0 for current view, and we might have pagination logic...
            // If simple infinite scroll, index + 1 is fine if we render all. 
            // If paginated by slice, it's relative. 
            // Current logic slices: visibleAgents = allFiltered.slice(0, visibleCount);
            // So visibleAgents contains elements from 0 to visibleCount.
            // The index in forEach is the correct global index (within filtered set).
            
            tr.innerHTML = `
                <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                        <div class="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">
                            AI
                        </div>
                        <div class="font-medium text-gray-900">${agent.name}</div>
                    </div>
                </td>
                <td class="px-6 py-4">
                    <button onclick="toggleAgentStatus('${agent.id}')" class="relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${agent.status === 'running' ? 'bg-green-500' : 'bg-gray-200'}">
                        <span class="sr-only">Use setting</span>
                        <span aria-hidden="true" class="pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${agent.status === 'running' ? 'translate-x-4' : 'translate-x-0'}"></span>
                    </button>
                    <span class="ml-2 text-xs ${agent.status === 'running' ? 'text-green-600' : 'text-gray-500'}">
                        ${agent.status === 'running' ? '运行中' : '已停止'}
                    </span>
                </td>
                <td class="px-6 py-4">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        ${agent.model || '未设置'}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm text-gray-500">
                     ${Array.isArray(agent.knowledgeBase) && agent.knowledgeBase.length > 0 ? agent.knowledgeBase.map(kb => `<span class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700 mr-1">${kb}</span>`).join('') : '-'}
                </td>
                <td class="px-6 py-4 text-sm text-gray-500">
                     <div class="flex items-center gap-2">
                        <div class="w-5 h-5 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xs">
                            <i class="fa-solid fa-user"></i>
                        </div>
                        ${agent.creator || 'Admin'}
                    </div>
                </td>
                <td class="px-6 py-4 text-xs text-gray-500">
                    ${agent.createdAt || '-'}
                </td>
                <td class="px-6 py-4 text-xs text-gray-500">
                    ${agent.updatedAt || '-'}
                </td>
                <td class="px-6 py-4 text-right">
                    <button onclick="window.openAgentActions(event, '${agent.id}')" class="p-1.5 text-gray-400 hover:text-gray-600 transition-colors rounded hover:bg-gray-100">
                        <i class="fa-solid fa-ellipsis"></i>
                    </button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }
}

// Action Menu Handler
window.openAgentActions = function(event, id) {
    window.showActionMenu(event, [
        {
            label: '编辑',
            icon: 'fa-solid fa-pen',
            onClick: () => editAgent(id)
        },
        {
            label: '删除',
            icon: 'fa-solid fa-trash',
            className: 'text-red-600 hover:bg-red-50',
            iconClass: 'text-red-500',
            onClick: () => openDeleteConfirm(id)
        }
    ]);
}

// Edit Agent (Ensure it's exposed)
window.editAgent = function(id) {
    if (typeof switchView === 'function') {
        switchView('agent-editor', { id: id });
    }
}

// Create Agent
function createNewAgent() {
    const nameInput = document.getElementById('new-agent-name');
    const modelInput = document.getElementById('new-agent-model');
    const descInput = document.getElementById('new-agent-desc');

    if (!nameInput.value.trim()) {
        alert('请输入智能体名称');
        return;
    }

    const newAgent = {
        id: window.generateId ? window.generateId('AGT') : `AGT-${Date.now()}`,
        name: nameInput.value,
        model: modelInput.value,
        description: descInput.value,
        prompt: descInput.value, // Use description as initial prompt
        hot: 0,
        status: 'running',
        createdAt: new Date().toLocaleString(),
        timestamp: Date.now(),
        updatedAt: new Date().toLocaleString()
    };

    agentsData.unshift(newAgent); // Add to top
    closeModal('create-agent-modal');
    
    // Clear inputs
    nameInput.value = '';
    descInput.value = '';
    
    // Instead of rendering list, switch to editor
    // currentPage = 1;
    // renderAgentList(true);
    // updateStats();
    
    // Go to editor
    switchView('agent-editor', { id: newAgent.id });
}

// Delete Agent
let agentToDeleteId = null;
let agentToStopId = null; // State for stop confirmation

function openDeleteConfirm(id) {
    agentToDeleteId = id;
    const agent = agentsData.find(a => a.id === id);
    if (agent) {
        document.getElementById('delete-agent-name').textContent = agent.name;
        openModal('delete-confirm-modal');
    }
}

function confirmDelete() {
    if (agentToDeleteId) {
        agentsData = agentsData.filter(a => a.id !== agentToDeleteId);
        closeModal('delete-confirm-modal');
        renderAgentList(true);
        updateStats();
        agentToDeleteId = null;
    }
}

// Bind confirm delete button (Global listener in case element is recreated, though modal is static in views/agent.html? No, modal is part of view, so it is re-injected)
// Since modal is part of the view, we need to bind the click event AFTER view load or use inline onclick.
// The HTML uses onclick="createNewAgent()" and onclick="confirmDelete()" but wait, confirmDelete is button id="confirm-delete-btn".
// In `views/agent.html`: <button id="confirm-delete-btn" ...>删除</button>
// So we need to bind it in initAgentPage or use onclick in HTML.
// Let's add onclick to the button in HTML to be safe and consistent with createNewAgent.

// Toggle Status
function toggleAgentStatus(id) {
    const agent = agentsData.find(a => a.id === id);
    if (agent) {
        if (agent.status === 'running') {
            // If running, ask for confirmation to stop
            agentToStopId = id;
            if (typeof openModal === 'function') {
                openModal('stop-confirm-modal');
            } else {
                // Fallback if openModal is not globally available (it should be in utils.js)
                const modal = document.getElementById('stop-confirm-modal');
                if (modal) modal.classList.remove('hidden');
            }
        } else {
            // If stopped, start immediately
            agent.status = 'running';
            renderAgentList(false);
        }
    }
}

function confirmStopAgent() {
    if (agentToStopId) {
        const agent = agentsData.find(a => a.id === agentToStopId);
        if (agent) {
            agent.status = 'stopped';
            renderAgentList(false);
        }
        
        if (typeof closeModal === 'function') {
            closeModal('stop-confirm-modal');
        } else {
             const modal = document.getElementById('stop-confirm-modal');
             if (modal) modal.classList.add('hidden');
        }
        agentToStopId = null;
    }
}

// Update Stats
function updateStats() {
    const countEl = document.getElementById('total-agents-count');
    if (countEl) countEl.textContent = agentsData.length;
}

// Listen for custom view loaded event
document.addEventListener('view-loaded', (e) => {
    if (e.detail.view === 'agent') {
        initAgentPage();
        
        // Bind Confirm Delete Button dynamically since it's re-rendered
        const deleteBtn = document.getElementById('confirm-delete-btn');
        if (deleteBtn) {
            deleteBtn.onclick = confirmDelete;
        }
    }
});

// Edit Agent
function editAgent(id) {
    switchView('agent-editor', { id: id });
}

// Helper to get agent by ID (exposed globally for editor)
window.getAgentById = function(id) {
    return agentsData.find(a => a.id === id);
};

// Expose functions
window.initAgentPage = initAgentPage;
window.createNewAgent = createNewAgent;
window.openDeleteConfirm = openDeleteConfirm;
window.toggleAgentStatus = toggleAgentStatus;
window.confirmStopAgent = confirmStopAgent;
window.editAgent = editAgent;

// --- Agent Editor Logic ---

let currentEditorAgentId = null;

// --- Resource Management Logic ---
let editorResources = {
    knowledge: [],
    agent: [],
    orchestrator: [],
    mcp: [],
    plugin: []
};

function loadResources() {
    // Check and load Knowledge Data
    if (typeof knowledgeData !== 'undefined' && knowledgeData.length === 0) {
        if (typeof generateMockKnowledge === 'function') {
            knowledgeData = generateMockKnowledge(10);
        }
    }
    
    // Check and load Orchestrator Data
    if (typeof orchestratorData !== 'undefined' && orchestratorData.length === 0) {
        if (typeof generateMockOrchestrators === 'function') {
            orchestratorData = generateMockOrchestrators(10);
        }
    }

    // Populate Selects
    // Knowledge
    if (typeof knowledgeData !== 'undefined') {
        populateSelect('select-knowledge', knowledgeData);
    }
    
    // Agents (exclude current)
    if (typeof agentsData !== 'undefined') {
        const availableAgents = agentsData.filter(a => a.id !== currentEditorAgentId);
        populateSelect('select-agent', availableAgents);
    }
    
    // Orchestrator
    if (typeof orchestratorData !== 'undefined') {
        populateSelect('select-orchestrator', orchestratorData);
    }

    // MCP
    if (typeof mcpData !== 'undefined') {
        populateSelect('select-mcp', mcpData);
    }

    // Plugins
    if (typeof pluginData !== 'undefined') {
        populateSelect('select-plugin', pluginData);
    }
}

function populateSelect(id, data) {
    const select = document.getElementById(id);
    if (!select) return;
    
    // Reset options but keep the first one
    select.innerHTML = select.options[0].outerHTML;
    
    data.forEach(item => {
        const option = document.createElement('option');
        option.value = item.id;
        option.textContent = item.name;
        select.appendChild(option);
    });
}

function addResource(type) {
    const select = document.getElementById(`select-${type}`);
    if (!select) return;
    
    const id = select.value;
    if (!id) return;
    
    if (!editorResources[type].includes(id)) {
        editorResources[type].push(id);
        renderResourceList(type);
    }
    
    // Reset select
    select.value = '';
}

function removeResource(type, id) {
    editorResources[type] = editorResources[type].filter(item => item !== id);
    renderResourceList(type);
}

function renderResourceList(type) {
    const container = document.getElementById(`list-${type}`);
    if (!container) return;
    
    container.innerHTML = '';
    
    editorResources[type].forEach(id => {
        let name = id;
        let data = [];
        
        if (type === 'knowledge' && typeof knowledgeData !== 'undefined') data = knowledgeData;
        else if (type === 'agent') data = agentsData;
        else if (type === 'orchestrator' && typeof orchestratorData !== 'undefined') data = orchestratorData;
        else if (type === 'mcp' && typeof mcpData !== 'undefined') data = mcpData;
        else if (type === 'plugin' && typeof pluginData !== 'undefined') data = pluginData;
        
        const item = data.find(x => x.id === id);
        if (item) name = item.name;
        
        const div = document.createElement('div');
        div.className = 'flex items-center justify-between p-2 bg-white rounded-md border border-gray-200 text-xs shadow-sm group hover:border-blue-300 transition-all';
        div.innerHTML = `
            <span class="text-gray-700 truncate mr-2 flex-1 flex items-center gap-2">
                <i class="fa-solid fa-link text-gray-300 text-[10px]"></i>
                ${name}
            </span>
            <button onclick="removeResource('${type}', '${id}')" class="text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                <i class="fa-solid fa-times"></i>
            </button>
        `;
        container.appendChild(div);
    });
}

// Expose resource functions
window.addResource = addResource;
window.removeResource = removeResource;

// Toggle Section
function toggleSection(contentId, headerElement) {
    const content = document.getElementById(contentId);
    if (!content) return;
    
    const isHidden = content.classList.contains('hidden');
    const chevron = headerElement.querySelector('.fa-chevron-down');
    
    // Save preference
    const savedState = JSON.parse(localStorage.getItem('agent_editor_sections_state') || '{}');
    savedState[contentId] = isHidden; // isHidden means we are about to open it (true)
    localStorage.setItem('agent_editor_sections_state', JSON.stringify(savedState));
    
    if (isHidden) {
        // Expanding
        content.classList.remove('hidden');
        
        // Get target dimensions
        const height = content.scrollHeight;
        
        // Set initial state
        content.style.height = '0px';
        content.style.opacity = '0';
        content.style.overflow = 'hidden';
        content.style.paddingTop = '0px';
        content.style.paddingBottom = '0px';
        content.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
        
        // Force reflow
        content.offsetHeight;
        
        // Animate to target
        content.style.height = height + 'px';
        content.style.opacity = '1';
        content.style.paddingTop = ''; // Revert to CSS defined
        content.style.paddingBottom = '';
        
        if (chevron) chevron.style.transform = 'rotate(0deg)';
        
        // Cleanup
        setTimeout(() => {
            content.style.removeProperty('height');
            content.style.removeProperty('opacity');
            content.style.removeProperty('overflow');
            content.style.removeProperty('transition');
            content.style.removeProperty('padding-top');
            content.style.removeProperty('padding-bottom');
        }, 300);
        
    } else {
        // Collapsing
        const height = content.scrollHeight;
        
        // Set start state
        content.style.height = height + 'px';
        content.style.overflow = 'hidden';
        content.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
        
        // Force reflow
        content.offsetHeight;
        
        // Animate to end state
        content.style.height = '0px';
        content.style.opacity = '0';
        content.style.paddingTop = '0px';
        content.style.paddingBottom = '0px';
        
        if (chevron) chevron.style.transform = 'rotate(-90deg)';
        
        // Cleanup
        setTimeout(() => {
            content.classList.add('hidden');
            content.style.removeProperty('height');
            content.style.removeProperty('overflow');
            content.style.removeProperty('transition');
            content.style.removeProperty('opacity');
            content.style.removeProperty('padding-top');
            content.style.removeProperty('padding-bottom');
        }, 300);
    }
}

function initSectionStates() {
    const savedStateStr = localStorage.getItem('agent_editor_sections_state');
    if (!savedStateStr) return; 

    const state = JSON.parse(savedStateStr);
    ['prompt-content', 'knowledge-content', 'skills-content', 'experience-content', 'advanced-content'].forEach(id => {
        const content = document.getElementById(id);
        if (!content) return;
        
        // Find header to update chevron
        const container = content.parentElement;
        const header = container.firstElementChild; 
        const chevron = header.querySelector('.fa-chevron-down');

        const shouldBeOpen = state[id]; 
        if (shouldBeOpen === undefined) return;

        if (shouldBeOpen) {
            content.classList.remove('hidden');
            if (chevron) chevron.style.transform = 'rotate(0deg)';
        } else {
            content.classList.add('hidden');
            if (chevron) chevron.style.transform = 'rotate(-90deg)';
        }
    });
}

window.toggleSection = toggleSection;

function initAgentEditor(params) {
    console.log('Initializing Agent Editor with params:', params);
    
    // Ensure data exists (in case of page reload directly on editor)
    if (typeof agentsData === 'undefined' || agentsData.length === 0) {
        agentsData = generateMockAgents(10);
    }
    
    // Reset Tabs
    switchEditorTab('config');
    
    // Initialize Resources State
    editorResources = {
        knowledge: [],
        agent: [],
        orchestrator: [],
        mcp: [],
        plugin: []
    };

    // Load Resources Options
    loadResources();
    
    // Load Data if ID exists
    if (params && params.id) {
        currentEditorAgentId = params.id;
        let agent = agentsData.find(a => a.id == params.id);
        
        // If agent not found (e.g. refresh with mock data), create a dummy one to keep UI working
        if (!agent) {
            agent = {
                id: params.id,
                name: '恢复的智能体',
                model: 'GPT-4o',
                description: '由于页面刷新，这是一个自动恢复的临时智能体数据。',
                prompt: '',
                knowledge: [],
                relatedAgents: [],
                orchestrators: [],
                createdAt: new Date().toLocaleString(),
                updatedAt: new Date().toLocaleString(),
                status: 'running'
            };
            agentsData.push(agent);
            showToast('已自动恢复智能体数据', 'info');
        }

        if (agent) {
            // Update Title
            const titleEl = document.getElementById('editor-title');
            if (titleEl) titleEl.textContent = `编辑智能体: ${agent.name}`;
            
            // Update Header Info
            const nameDisplay = document.getElementById('agent-name-display');
            const descDisplay = document.getElementById('agent-desc-display');
            const avatarDisplay = document.getElementById('editor-agent-avatar');
            
            if (nameDisplay) nameDisplay.textContent = agent.name;
            if (descDisplay) descDisplay.textContent = agent.description || '暂无描述';
            
            if (avatarDisplay) {
                if (agent.avatar) {
                    avatarDisplay.innerHTML = `<img src="${agent.avatar}" class="w-full h-full object-cover rounded-xl">`;
                } else {
                    avatarDisplay.innerHTML = '<i class="fa-solid fa-robot"></i>';
                }
            }
            
            // Populate Form
            const nameInput = document.getElementById('agent-name');
            const modelInput = document.getElementById('agent-model');
            const promptInput = document.getElementById('agent-prompt');
            
            if (nameInput) nameInput.value = agent.name;
            if (modelInput) modelInput.value = agent.model;
            if (promptInput && agent.prompt) promptInput.value = agent.prompt;

            // Load Agent's Resources
            if (agent.knowledge) editorResources.knowledge = [...agent.knowledge];
            if (agent.relatedAgents) editorResources.agent = [...agent.relatedAgents];
            if (agent.orchestrators) editorResources.orchestrator = [...agent.orchestrators];
            if (agent.mcp) editorResources.mcp = [...(agent.mcp || [])];
            if (agent.plugin) editorResources.plugin = [...(agent.plugin || [])];

            // Load Show Knowledge Source Preference
            const showSourceToggle = document.getElementById('show-knowledge-source');
            if (showSourceToggle) {
                showSourceToggle.checked = agent.showKnowledgeSource || false;
                // Trigger visual update
                toggleKnowledgeSource();
            }
        }
    } else {
        currentEditorAgentId = null;
        currentAvatarDataUrl = null; // Clear avatar
        
        // New Agent Mode
        const titleEl = document.getElementById('editor-title');
        if (titleEl) titleEl.textContent = '新建智能体';
        
        // Update Header Info to Default
        const nameDisplay = document.getElementById('agent-name-display');
        const descDisplay = document.getElementById('agent-desc-display');
        const avatarDisplay = document.getElementById('editor-agent-avatar');
        
        if (nameDisplay) nameDisplay.textContent = '未命名智能体';
        if (descDisplay) descDisplay.textContent = '暂无描述';
        if (avatarDisplay) avatarDisplay.innerHTML = '<i class="fa-solid fa-robot"></i>';

        // Clear inputs
        const nameInput = document.getElementById('agent-name');
        const modelInput = document.getElementById('agent-model');
        const promptInput = document.getElementById('agent-prompt');
        const showSourceToggle = document.getElementById('show-knowledge-source');

        if (nameInput) nameInput.value = '';
        if (modelInput) modelInput.value = '';
        if (promptInput) promptInput.value = '';
        if (showSourceToggle) {
            showSourceToggle.checked = false;
            toggleKnowledgeSource();
        }
    }

    // Render Initial Lists
    renderResourceList('knowledge');
    renderResourceList('agent');
    renderResourceList('orchestrator');
    renderResourceList('mcp');
    renderResourceList('plugin');
    
    // Initialize Section States (Expand/Collapse)
    if (typeof initSectionStates === 'function') {
        initSectionStates();
    }
}

function switchEditorTab(tabId) {
    // Hide all contents
    ['config', 'publish', 'logs', 'analytics'].forEach(id => {
        const content = document.getElementById(`tab-content-${id}`);
        const btn = document.getElementById(`tab-btn-${id}`);
        
        if (content) content.classList.add('hidden');
        if (btn) {
            btn.classList.remove('text-blue-600', 'border-blue-600');
            btn.classList.add('text-gray-500', 'border-transparent');
        }
    });
    
    // Show selected
    const content = document.getElementById(`tab-content-${tabId}`);
    const btn = document.getElementById(`tab-btn-${tabId}`);
    
    if (content) content.classList.remove('hidden');
    if (btn) {
        btn.classList.remove('text-gray-500', 'border-transparent');
        btn.classList.add('text-blue-600', 'border-blue-600');
    }
    
    // Refresh Logs if needed
    if (tabId === 'logs') {
        renderLogList(true);
    }
}

function toggleKnowledgeSource() {
    const showSourceToggle = document.getElementById('show-knowledge-source');
    const previewSource = document.getElementById('preview-knowledge-source');
    
    if (showSourceToggle && previewSource) {
        if (showSourceToggle.checked) {
            previewSource.classList.remove('hidden');
        } else {
            previewSource.classList.add('hidden');
        }
    }
}

window.toggleKnowledgeSource = toggleKnowledgeSource;

function saveAgentConfig() {
    // Show saving feedback
    const btn = document.querySelector('button[onclick="saveAgentConfig()"]');
    const originalText = btn ? btn.innerHTML : '保存配置';
    
    if (btn) {
        btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> 保存中...';
        btn.disabled = true;
    }
    
    const nameInput = document.getElementById('agent-name');
    const modelInput = document.getElementById('agent-model');
    const promptInput = document.getElementById('agent-prompt');
    const welcomeMsgInput = document.getElementById('welcome-msg-input');
    const showSourceToggle = document.getElementById('show-knowledge-source');
    
    // Save to Data
    if (currentEditorAgentId) {
        const agent = agentsData.find(a => a.id === currentEditorAgentId);
        if (agent) {
            if (nameInput) agent.name = nameInput.value;
            if (modelInput) agent.model = modelInput.value;
            if (promptInput) agent.prompt = promptInput.value;
            if (welcomeMsgInput) agent.welcomeMessage = welcomeMsgInput.value;
            if (showSourceToggle) agent.showKnowledgeSource = showSourceToggle.checked;

            agent.updatedAt = new Date().toLocaleString();
            agent.knowledge = editorResources.knowledge;
            agent.relatedAgents = editorResources.agent;
            agent.orchestrators = editorResources.orchestrator;
            agent.mcp = editorResources.mcp;
            agent.plugin = editorResources.plugin;
        }
    } else {
        // Create New Agent
        const newId = window.generateId ? window.generateId('AGT') : `AGT-${Date.now()}`;
        const newAgent = {
            id: newId,
            name: nameInput ? nameInput.value : '未命名',
            model: modelInput ? modelInput.value : 'GPT-4o',
            prompt: promptInput ? promptInput.value : '',
            welcomeMessage: welcomeMsgInput ? welcomeMsgInput.value : '',
            showKnowledgeSource: showSourceToggle ? showSourceToggle.checked : false,
            description: nameInput && nameInput.dataset.description ? nameInput.dataset.description : '',
            avatar: currentAvatarDataUrl,
            knowledge: editorResources.knowledge,
            relatedAgents: editorResources.agent,
            orchestrators: editorResources.orchestrator,
            mcp: editorResources.mcp,
            plugin: editorResources.plugin,
            createdAt: new Date().toLocaleString(),
            updatedAt: new Date().toLocaleString(),
            timestamp: Date.now(),
            status: 'running',
            creator: 'Admin',
            hot: 0
        };
        
        agentsData.unshift(newAgent);
        currentEditorAgentId = newId;
        
        // Update Title to "Edit..."
        const editorTitle = document.getElementById('editor-title');
        if (editorTitle) editorTitle.textContent = `编辑智能体: ${newAgent.name}`;
    }

    setTimeout(() => {
        if (btn) {
            btn.innerHTML = originalText;
            btn.disabled = false;
        }
        
        // Update List View if needed (not visible)
        renderAgentList(true);
        
        alert('配置已保存');
    }, 1000);
}

// Expose editor functions
window.initAgentEditor = initAgentEditor;
window.switchEditorTab = switchEditorTab;
window.saveAgentConfig = saveAgentConfig;

// Copy Web Preview Link
function copyWebLink() {
    const link = "https://chat.vagent.ai/preview/ag_839201";
    navigator.clipboard.writeText(link).then(() => {
        showToast('链接已复制到剪贴板');
    }).catch(err => {
        console.error('Failed to copy: ', err);
        // Fallback for non-secure contexts if needed, or just alert
        showToast('复制失败', 'error');
    });
}

// Copy SDK Code
function copySdkCode() {
    const codeBlock = document.getElementById('sdk-code-block');
    if (codeBlock) {
        const code = codeBlock.textContent;
        navigator.clipboard.writeText(code).then(() => {
            showToast('SDK 代码已复制');
        }).catch(err => {
            console.error('Failed to copy: ', err);
            showToast('复制失败', 'error');
        });
    }
}

window.copyWebLink = copyWebLink;
window.copySdkCode = copySdkCode;

// Save Component Config
function saveComponentConfig() {
    closeModal('component-config-modal');
    showToast('组件配置已保存');
}

window.saveComponentConfig = saveComponentConfig;

// --- Logs Management Logic ---

let logsData = [];
let currentLogSearch = '';
let currentLogFilter = 'all';

// Generate Mock Logs
function generateMockLogs(count) {
    const logs = [];
    const users = ['User_8392', 'User_1204', 'User_5593', 'User_9921', 'User_3322'];
    const topics = ['Python Hello World', 'DeepSeek V2 评价', 'Translate to Chinese', '写一个 SQL 查询', 'React 组件优化', '解释量子纠缠', '生成周报'];
    const statuses = ['active', 'completed'];
    
    for (let i = 0; i < count; i++) {
        const date = new Date(Date.now() - Math.floor(Math.random() * 1000000000)); // Random time in last ~11 days
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const msgCount = Math.floor(Math.random() * 20) + 2;
        
        logs.push({
            id: `sess_${Math.floor(Math.random() * 100000000)}`,
            user: users[Math.floor(Math.random() * users.length)],
            agentName: '我的智能体', // Should match current agent name but hardcoded for now or use context
            status: status,
            topic: topics[Math.floor(Math.random() * topics.length)],
            messageCount: msgCount,
            createdAt: date.toLocaleString(),
            updatedAt: new Date(date.getTime() + Math.floor(Math.random() * 3600000)).toLocaleString(),
            content: generateMockChatContent(msgCount)
        });
    }
    return logs.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
}

function generateMockChatContent(count) {
    const content = [];
    const interactions = [
        { role: 'user', text: '你好' },
        { role: 'ai', text: '你好！有什么我可以帮你的吗？' },
        { role: 'user', text: '帮我写个代码' },
        { role: 'ai', text: '好的，请告诉我你需要什么语言的代码？' },
        { role: 'user', text: 'Python' },
        { role: 'ai', text: '这是一个 Python 示例...' }
    ];
    
    for (let i = 0; i < count; i++) {
        content.push(interactions[i % interactions.length]);
    }
    return content;
}

function renderLogList(reset = false) {
    if (reset || logsData.length === 0) {
        logsData = generateMockLogs(15);
        
        // Bind search/filter events if not already bound
        const searchInput = document.getElementById('log-search');
        if (searchInput && !searchInput.dataset.bound) {
            searchInput.addEventListener('input', (e) => {
                currentLogSearch = e.target.value.toLowerCase();
                renderLogList(false);
            });
            searchInput.dataset.bound = true;
        }
        
        const filterSelect = document.getElementById('log-filter-status');
        if (filterSelect && !filterSelect.dataset.bound) {
            filterSelect.addEventListener('change', (e) => {
                currentLogFilter = e.target.value;
                renderLogList(false);
            });
            filterSelect.dataset.bound = true;
        }
    }

    const tbody = document.getElementById('logs-list-body');
    const emptyState = document.getElementById('logs-list-empty');
    if (!tbody) return;

    // Filter
    const filtered = logsData.filter(log => {
        const matchesSearch = log.id.toLowerCase().includes(currentLogSearch) || 
                              log.user.toLowerCase().includes(currentLogSearch) ||
                              log.topic.toLowerCase().includes(currentLogSearch);
        const matchesStatus = currentLogFilter === 'all' || log.status === currentLogFilter;
        return matchesSearch && matchesStatus;
    });

    tbody.innerHTML = '';

    if (filtered.length === 0) {
        if (emptyState) emptyState.classList.remove('hidden');
    } else {
        if (emptyState) emptyState.classList.add('hidden');
        
        filtered.forEach(log => {
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-gray-50 transition-colors cursor-pointer';
            tr.onclick = (e) => {
                // Prevent click if clicking specific buttons if any
                if (e.target.closest('button')) return;
                openLogDetailModal(log.id);
            };
            
            const statusClass = log.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';
            const statusText = log.status === 'active' ? '进行中' : '已结束';

            tr.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-blue-600 font-mono">
                    ${log.id}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div class="flex items-center gap-2">
                        <div class="w-6 h-6 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center text-xs">
                            <i class="fa-solid fa-user"></i>
                        </div>
                        ${log.user}
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${log.agentName}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusClass}">
                        ${statusText}
                    </span>
                </td>
                <td class="px-6 py-4 text-sm text-gray-900 max-w-xs truncate" title="${log.topic}">
                    ${log.topic}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${log.messageCount}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${log.createdAt}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${log.updatedAt}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onclick="openLogDetailModal('${log.id}')" class="text-blue-600 hover:text-blue-900">查看</button>
                </td>
            `;
            tbody.appendChild(tr);
        });
    }
}

function openLogDetailModal(logId) {
    const log = logsData.find(l => l.id === logId);
    if (!log) return;

    document.getElementById('log-detail-title').textContent = `会话详情: ${log.topic}`;
    document.getElementById('log-detail-meta').textContent = `ID: ${log.id} • 用户: ${log.user} • 时间: ${log.createdAt}`;
    
    const contentContainer = document.getElementById('log-detail-content');
    contentContainer.innerHTML = '';

    log.content.forEach(msg => {
        const isUser = msg.role === 'user';
        const div = document.createElement('div');
        div.className = isUser ? 'flex gap-3 flex-row-reverse mb-4' : 'flex gap-3 mb-4';
        
        div.innerHTML = `
            <div class="w-8 h-8 rounded-full ${isUser ? 'bg-gray-200 text-gray-600' : 'bg-blue-100 text-blue-600'} flex items-center justify-center text-xs flex-shrink-0">
                <i class="fa-solid fa-${isUser ? 'user' : 'robot'}"></i>
            </div>
            <div class="${isUser ? 'bg-blue-600 text-white rounded-tr-none' : 'bg-white text-gray-800 border border-gray-100 rounded-tl-none'} rounded-2xl px-4 py-2.5 text-sm max-w-[80%] shadow-sm">
                ${msg.text}
            </div>
        `;
        contentContainer.appendChild(div);
    });

    openModal('log-detail-modal');
}

// Expose functions
window.renderLogList = renderLogList;
window.openLogDetailModal = openLogDetailModal;

// --- Edit Agent Info (Name & Desc & Avatar) ---

let currentAvatarDataUrl = null;
let cropperInstance = null;

function openEditAgentInfoModal() {
    // Allow opening even if new agent (currentEditorAgentId is null)
    
    let agentName = '';
    let agentDesc = '';
    
    if (currentEditorAgentId) {
        const agent = agentsData.find(a => a.id == currentEditorAgentId);
        if (agent) {
            agentName = agent.name || '';
            agentDesc = agent.description || '';
            currentAvatarDataUrl = agent.avatar || null;
        }
    } else {
        // New Agent Mode - Try to get from main input if user typed something
        const mainNameInput = document.getElementById('agent-name');
        if (mainNameInput) agentName = mainNameInput.value;
        // currentAvatarDataUrl should be preserved from previous crop in this session if any
    }

    const nameInput = document.getElementById('edit-agent-name');
    const descInput = document.getElementById('edit-agent-desc');
    const avatarPreview = document.getElementById('edit-agent-avatar-preview');
    
    if (nameInput) nameInput.value = agentName;
    if (descInput) descInput.value = agentDesc;
    
    updateAvatarPreview(avatarPreview, currentAvatarDataUrl);
    
    openModal('edit-agent-info-modal');
}

function updateAvatarPreview(element, url) {
    if (!element) return;
    if (url) {
        element.innerHTML = `<img src="${url}" class="w-full h-full object-cover">`;
    } else {
        element.innerHTML = '<i class="fa-solid fa-robot"></i>';
    }
}

function handleAvatarSelect(input) {
    if (!input.files || !input.files[0]) return;
    
    const file = input.files[0];
    
    // Validation
    if (!['image/jpeg', 'image/png'].includes(file.type)) {
        showToast('仅支持 JPG 或 PNG 格式图片', 'error');
        input.value = '';
        return;
    }
    
    if (file.size > 2 * 1024 * 1024) {
        showToast('图片大小不能超过 2MB', 'error');
        input.value = '';
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        openCropModal(e.target.result);
    };
    reader.readAsDataURL(file);
    
    // Clear input so same file can be selected again if cancelled
    input.value = '';
}

function openCropModal(imageUrl) {
    const image = document.getElementById('crop-image');
    if (!image) return;
    
    image.src = imageUrl;
    openModal('crop-modal');
    
    // Destroy previous instance if any
    if (cropperInstance) {
        cropperInstance.destroy();
    }
    
    // Init Cropper
    // Use timeout to ensure modal is visible for correct calculation
    setTimeout(() => {
        cropperInstance = new Cropper(image, {
            aspectRatio: 1,
            viewMode: 1,
            dragMode: 'move',
            autoCropArea: 0.8,
            restore: false,
            guides: true,
            center: true,
            highlight: false,
            cropBoxMovable: true,
            cropBoxResizable: true,
            toggleDragModeOnDblclick: false,
        });
    }, 200);
}

function confirmCrop() {
    if (!cropperInstance) return;
    
    // Get cropped canvas
    const canvas = cropperInstance.getCroppedCanvas({
        width: 200,
        height: 200,
    });
    
    currentAvatarDataUrl = canvas.toDataURL('image/png');
    
    // Update Preview in Edit Modal
    const avatarPreview = document.getElementById('edit-agent-avatar-preview');
    updateAvatarPreview(avatarPreview, currentAvatarDataUrl);
    
    closeModal('crop-modal');
}

function saveAgentInfo() {
    const nameInput = document.getElementById('edit-agent-name');
    const descInput = document.getElementById('edit-agent-desc');
    
    const newName = nameInput.value.trim();
    if (!newName) {
        showToast('请输入智能体名称', 'error');
        return;
    }

    // Update Data if existing
    if (currentEditorAgentId) {
        const agent = agentsData.find(a => a.id === currentEditorAgentId);
        if (agent) {
            agent.name = newName;
            agent.description = descInput.value.trim();
            agent.avatar = currentAvatarDataUrl;
            agent.updatedAt = new Date().toLocaleString();
        }
    }

    // Update UI
    const nameDisplay = document.getElementById('agent-name-display');
    const descDisplay = document.getElementById('agent-desc-display');
    const editorTitle = document.getElementById('editor-title');
    const headerAvatarContainer = document.getElementById('editor-agent-avatar');
    
    if (nameDisplay) nameDisplay.textContent = newName;
    if (descDisplay) descDisplay.textContent = descInput.value.trim() || '暂无描述';
    if (editorTitle) editorTitle.textContent = currentEditorAgentId ? `编辑智能体: ${newName}` : newName;
    
    // Update main avatar logic
    if (headerAvatarContainer) {
        if (currentAvatarDataUrl) {
            headerAvatarContainer.innerHTML = `<img src="${currentAvatarDataUrl}" class="w-full h-full object-cover rounded-xl">`;
        } else {
             headerAvatarContainer.innerHTML = '<i class="fa-solid fa-robot"></i>';
        }
    }

    // Also update the hidden/main form inputs if they exist (to keep sync)
    const mainNameInput = document.getElementById('agent-name');
    if (mainNameInput) {
        mainNameInput.value = newName;
        // Store description in dataset for later save
        mainNameInput.dataset.description = descInput.value.trim();
    }

    closeModal('edit-agent-info-modal');
    showToast('基本信息已更新');
}

window.openEditAgentInfoModal = openEditAgentInfoModal;
window.handleAvatarSelect = handleAvatarSelect;
window.confirmCrop = confirmCrop;
window.saveAgentInfo = saveAgentInfo;

// --- Version Control & Publishing ---

function publishAgent() {
    if (!currentEditorAgentId) {
        showToast('请先保存智能体基本信息', 'error');
        return;
    }
    
    const agent = agentsData.find(a => a.id === currentEditorAgentId);
    if (!agent) return;

    // Capture current config
    const nameInput = document.getElementById('agent-name');
    const modelInput = document.getElementById('agent-model');
    const promptInput = document.getElementById('agent-prompt');
    
    const config = {
        name: nameInput ? nameInput.value : agent.name,
        model: modelInput ? modelInput.value : agent.model,
        prompt: promptInput ? promptInput.value : agent.prompt,
        knowledge: [...editorResources.knowledge],
        relatedAgents: [...editorResources.agent],
        orchestrators: [...editorResources.orchestrator]
    };

    // Update agent current config
    agent.name = config.name;
    agent.model = config.model;
    agent.prompt = config.prompt;
    agent.knowledge = config.knowledge;
    agent.relatedAgents = config.relatedAgents;
    agent.orchestrators = config.orchestrators;
    agent.updatedAt = new Date().toLocaleString();
    agent.timestamp = Date.now();

    // Create version
    if (!agent.versions) agent.versions = [];
    const versionId = `v${agent.versions.length + 1}.0`;
    agent.versions.unshift({
        id: versionId,
        timestamp: Date.now(),
        date: new Date().toLocaleString(),
        creator: 'Admin', // Mock
        config: { ...config },
        desc: `Updates to prompt and model configuration` // Mock description
    });

    // Show Success Modal
    openModal('publish-success-modal');
}

function confirmPublish() {
    const isPublishToMarket = document.getElementById('publish-to-market-check').checked;
    
    closeModal('publish-success-modal');
    
    if (isPublishToMarket) {
        showToast('发布成功！已同步至组件广场');
    } else {
        showToast('发布成功！');
    }
}

function openVersionHistory() {
    if (!currentEditorAgentId) return;
    
    const agent = agentsData.find(a => a.id === currentEditorAgentId);
    if (!agent) return;

    // Mock history if empty
    if (!agent.versions || agent.versions.length === 0) {
        if (!agent.versions) agent.versions = [];
         agent.versions.push({
            id: 'v1.0',
            timestamp: Date.now() - 86400000,
            date: new Date(Date.now() - 86400000).toLocaleString(),
            creator: 'Admin',
            config: { name: agent.name, model: agent.model, prompt: "Initial prompt..." },
            desc: 'Initial release'
        });
    }

    const container = document.getElementById('version-list-container');
    container.innerHTML = agent.versions.map((v, index) => `
        <div class="flex items-start gap-4 p-4 rounded-lg border border-gray-100 bg-gray-50 hover:bg-white hover:shadow-sm transition-all">
            <div class="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs flex-shrink-0">
                ${v.id}
            </div>
            <div class="flex-1">
                <div class="flex items-center justify-between mb-1">
                    <h4 class="text-sm font-semibold text-gray-900">发布于 ${v.date}</h4>
                    ${index === 0 ? '<span class="px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-700">当前版本</span>' : ''}
                </div>
                <p class="text-xs text-gray-500 mb-2">操作人: ${v.creator || 'Admin'}</p>
                <p class="text-sm text-gray-600 mb-3">${v.desc || '常规更新'}</p>
                
                ${index !== 0 ? `
                <button onclick="restoreVersion('${v.id}')" class="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
                    <i class="fa-solid fa-clock-rotate-left"></i> 回滚到此版本
                </button>
                ` : ''}
            </div>
        </div>
    `).join('');
    
    openModal('version-history-modal');
}

function restoreVersion(versionId) {
    if (!currentEditorAgentId) return;
    const agent = agentsData.find(a => a.id === currentEditorAgentId);
    if (!agent) return;
    
    const version = agent.versions.find(v => v.id === versionId);
    if (!version) return;
    
    // Restore config
    const nameInput = document.getElementById('agent-name');
    const modelInput = document.getElementById('agent-model');
    const promptInput = document.getElementById('agent-prompt');

    if (nameInput) nameInput.value = version.config.name;
    if (modelInput) modelInput.value = version.config.model;
    if (promptInput) promptInput.value = version.config.prompt;
    
    // Restore resources
    if (version.config.knowledge) editorResources.knowledge = [...version.config.knowledge];
    else editorResources.knowledge = [];
    
    if (version.config.relatedAgents) editorResources.agent = [...version.config.relatedAgents];
    else editorResources.agent = [];

    if (version.config.orchestrators) editorResources.orchestrator = [...version.config.orchestrators];
    else editorResources.orchestrator = [];

    renderResourceList('knowledge');
    renderResourceList('agent');
    renderResourceList('orchestrator');
    
    closeModal('version-history-modal');
    showToast(`已回滚到版本 ${versionId}`);
}

window.publishAgent = publishAgent;
window.confirmPublish = confirmPublish;
window.openVersionHistory = openVersionHistory;
window.restoreVersion = restoreVersion;

// --- Experience Configuration Logic ---

let experienceConfig = {
    welcomeMsg: "您好！我是您的AI助手，请问有什么可以帮您？",
    welcomeQuestions: { enabled: false, list: ['如何使用这个智能体？', '你能做什么？', '给我写个代码示例'] },
    responseQuestions: { enabled: false, list: [] },
    feedback: { enabled: false, mandatory: false, custom: false, options: ['回答不准确', '回答不完整', '不符合预期'] }
};

function initExperienceConfig(agent) {
    // Default Config
    experienceConfig = {
        welcomeMsg: "您好！我是您的AI助手，请问有什么可以帮您？",
        welcomeQuestions: { enabled: false, list: ['如何使用这个智能体？', '你能做什么？', '给我写个代码示例'] },
        responseQuestions: { enabled: false, list: [] },
        feedback: { enabled: false, mandatory: false, custom: false, options: ['回答不准确', '回答不完整', '不符合预期'] }
    };

    if (agent && agent.experience) {
        try {
            const saved = agent.experience;
            if (saved.welcomeMsg !== undefined) experienceConfig.welcomeMsg = saved.welcomeMsg;
            
            if (saved.welcomeQuestions) {
                experienceConfig.welcomeQuestions.enabled = !!saved.welcomeQuestions.enabled;
                if (Array.isArray(saved.welcomeQuestions.list)) {
                    experienceConfig.welcomeQuestions.list = [...saved.welcomeQuestions.list];
                }
            }
            
            if (saved.responseQuestions) {
                experienceConfig.responseQuestions.enabled = !!saved.responseQuestions.enabled;
                if (Array.isArray(saved.responseQuestions.list)) {
                    experienceConfig.responseQuestions.list = [...saved.responseQuestions.list];
                }
            }
            
            if (saved.feedback) {
                experienceConfig.feedback.enabled = !!saved.feedback.enabled;
                experienceConfig.feedback.mandatory = !!saved.feedback.mandatory;
                experienceConfig.feedback.custom = !!saved.feedback.custom;
                if (Array.isArray(saved.feedback.options)) {
                    experienceConfig.feedback.options = [...saved.feedback.options];
                }
            }
        } catch (e) {
            console.error("Error loading experience config:", e);
        }
    }
    renderExperienceConfig();
}

let sortableInstances = {};

function setupSortableLists() {
    const lists = [
        { id: 'welcome-questions-list', type: 'welcome' },
        { id: 'response-questions-list', type: 'response' },
        { id: 'feedback-options-list', type: 'feedback' }
    ];

    lists.forEach(item => {
        const el = document.getElementById(item.id);
        if (el) {
            if (sortableInstances[item.id]) {
                sortableInstances[item.id].destroy();
            }

            sortableInstances[item.id] = new Sortable(el, {
                handle: '.drag-handle',
                animation: 150,
                ghostClass: 'bg-blue-50',
                onEnd: function (evt) {
                    const oldIndex = evt.oldIndex;
                    const newIndex = evt.newIndex;
                    
                    if (oldIndex === newIndex) return;

                    let list;
                    if (item.type === 'welcome') {
                        list = experienceConfig.welcomeQuestions.list;
                    } else if (item.type === 'response') {
                        list = experienceConfig.responseQuestions.list;
                    } else if (item.type === 'feedback') {
                        list = experienceConfig.feedback.options;
                    }
                    
                    if (list) {
                        const [moved] = list.splice(oldIndex, 1);
                        list.splice(newIndex, 0, moved);
                        
                        renderExperienceConfig();
                        saveAgentConfig(true);
                    }
                }
            });
        }
    });
}

function renderExperienceConfig() {
    // Welcome Message
    const welcomeInput = document.getElementById('welcome-msg-input');
    if (welcomeInput) welcomeInput.value = experienceConfig.welcomeMsg;
    
    // Welcome Questions
    const welcomeCheck = document.getElementById('welcome-questions-check');
    const welcomeList = document.getElementById('welcome-questions-list');
    const welcomeSection = document.getElementById('welcome-questions-section');
    
    if (welcomeCheck) {
        welcomeCheck.checked = experienceConfig.welcomeQuestions.enabled;
        if (welcomeSection) {
             if (experienceConfig.welcomeQuestions.enabled) {
                 welcomeSection.classList.remove('hidden');
             } else {
                 welcomeSection.classList.add('hidden');
             }
        }
    }
    
    if (welcomeList) {
        welcomeList.innerHTML = experienceConfig.welcomeQuestions.list.map((q, i) => `
            <div class="flex items-center gap-2 group bg-white border border-gray-100 rounded-lg p-1">
                <div class="drag-handle cursor-grab text-gray-400 hover:text-gray-600 px-2 py-1 flex items-center justify-center">
                    <i class="fa-solid fa-grip-vertical text-xs"></i>
                </div>
                <input type="text" value="${q}" onchange="updateQuestion('welcome', ${i}, this.value)" class="flex-1 px-3 py-1.5 text-xs border border-gray-200 rounded focus:outline-none focus:border-blue-500">
                <button onclick="removeQuestion('welcome', ${i})" class="text-gray-400 hover:text-red-500 px-2"><i class="fa-solid fa-trash"></i></button>
            </div>
        `).join('');
    }

    // Response Questions
    const responseCheck = document.getElementById('response-questions-check');
    const responseList = document.getElementById('response-questions-list');
    const responseSection = document.getElementById('response-questions-section');
    
    if (responseCheck) {
        responseCheck.checked = experienceConfig.responseQuestions.enabled;
        if (responseSection) {
             if (experienceConfig.responseQuestions.enabled) {
                 responseSection.classList.remove('hidden');
             } else {
                 responseSection.classList.add('hidden');
             }
        }
    }
    
    if (responseList) {
        responseList.innerHTML = experienceConfig.responseQuestions.list.map((q, i) => `
            <div class="flex items-center gap-2 group bg-white border border-gray-100 rounded-lg p-1">
                <div class="drag-handle cursor-grab text-gray-400 hover:text-gray-600 px-2 py-1 flex items-center justify-center">
                    <i class="fa-solid fa-grip-vertical text-xs"></i>
                </div>
                <input type="text" value="${q}" onchange="updateQuestion('response', ${i}, this.value)" class="flex-1 px-3 py-1.5 text-xs border border-gray-200 rounded focus:outline-none focus:border-blue-500">
                <button onclick="removeQuestion('response', ${i})" class="text-gray-400 hover:text-red-500 px-2"><i class="fa-solid fa-trash"></i></button>
            </div>
        `).join('');
    }

    // Feedback
    const feedbackCheck = document.getElementById('feedback-check');
    const feedbackSection = document.getElementById('feedback-settings-section');
    
    if (feedbackCheck) {
        feedbackCheck.checked = experienceConfig.feedback.enabled;
        if (feedbackSection) {
            if (experienceConfig.feedback.enabled) {
                feedbackSection.classList.remove('hidden');
            } else {
                feedbackSection.classList.add('hidden');
            }
        }
    }
    
    const feedbackMandatory = document.getElementById('feedback-mandatory-check');
    if (feedbackMandatory) feedbackMandatory.checked = experienceConfig.feedback.mandatory;
    
    const feedbackCustom = document.getElementById('feedback-custom-check');
    if (feedbackCustom) feedbackCustom.checked = experienceConfig.feedback.custom;

    // Feedback Options List (Dynamic)
    const feedbackOptionsList = document.getElementById('feedback-options-list');
    if (feedbackOptionsList) {
        feedbackOptionsList.innerHTML = experienceConfig.feedback.options.map((opt, i) => `
            <div class="flex items-center gap-2 group bg-white border border-gray-100 rounded-lg p-1">
                <div class="drag-handle cursor-grab text-gray-400 hover:text-gray-600 px-2 py-1 flex items-center justify-center">
                    <i class="fa-solid fa-grip-vertical text-xs"></i>
                </div>
                <div class="flex-1 px-3 py-1.5 text-xs border border-gray-100 bg-gray-50 rounded text-gray-600">${opt}</div>
                <button onclick="removeFeedbackOption(${i})" class="text-gray-400 hover:text-red-500 px-2"><i class="fa-solid fa-trash"></i></button>
            </div>
        `).join('');
    }

    setupSortableLists();
}

function toggleExperienceFeature(feature) {
    if (feature === 'welcome') {
        experienceConfig.welcomeQuestions.enabled = !experienceConfig.welcomeQuestions.enabled;
    } else if (feature === 'response') {
        experienceConfig.responseQuestions.enabled = !experienceConfig.responseQuestions.enabled;
    } else if (feature === 'feedback') {
        experienceConfig.feedback.enabled = !experienceConfig.feedback.enabled;
    } else if (feature === 'feedback-mandatory') {
        experienceConfig.feedback.mandatory = !experienceConfig.feedback.mandatory;
    } else if (feature === 'feedback-custom') {
        experienceConfig.feedback.custom = !experienceConfig.feedback.custom;
    }
    renderExperienceConfig();
    saveAgentConfig(true); // Silent save
}

function previewWelcomeMessage() {
    const container = document.getElementById('preview-chat-container');
    if (!container) return;
    
    const msg = experienceConfig.welcomeMsg || "您好！我是您的AI助手，请问有什么可以帮您？";
    
    container.innerHTML = `
        <div class="flex gap-3">
            <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 flex-shrink-0">
                <i class="fa-solid fa-robot"></i>
            </div>
            <div class="bg-gray-100 rounded-2xl rounded-tl-none px-4 py-2.5 text-sm text-gray-800 max-w-[80%]">
                ${msg}
            </div>
        </div>
    `;
    
    // Also append recommended questions if enabled
    if (experienceConfig.welcomeQuestions.enabled && experienceConfig.welcomeQuestions.list.length > 0) {
        const questionsHtml = experienceConfig.welcomeQuestions.list.map(q => 
            `<div class="px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs text-blue-600 hover:bg-blue-50 cursor-pointer transition-colors mb-2 last:mb-0">${q}</div>`
        ).join('');
        
        const qContainer = document.createElement('div');
        qContainer.className = "flex gap-3";
        qContainer.innerHTML = `
            <div class="w-8 h-8 flex-shrink-0"></div>
            <div class="flex flex-col items-start">
                ${questionsHtml}
            </div>
        `;
        container.appendChild(qContainer);
    }
}

function updateQuestion(type, index, value) {
    if (type === 'welcome') {
        experienceConfig.welcomeQuestions.list[index] = value;
    } else {
        experienceConfig.responseQuestions.list[index] = value;
    }
    saveAgentConfig(true);
}

function addQuestion(type) {
    if (type === 'welcome') {
        if (experienceConfig.welcomeQuestions.list.length >= 8) {
            alert('最多添加8个推荐问题');
            return;
        }
        experienceConfig.welcomeQuestions.list.push('新问题');
    } else {
        if (experienceConfig.responseQuestions.list.length >= 5) {
            alert('最多添加5个推荐问题');
            return;
        }
        experienceConfig.responseQuestions.list.push('新推荐问题');
    }
    renderExperienceConfig();
    saveAgentConfig(true);
}

function removeQuestion(type, index) {
    if (type === 'welcome') {
        if (experienceConfig.welcomeQuestions.list.length <= 1) {
            alert('至少保留1个推荐问题');
            return;
        }
        experienceConfig.welcomeQuestions.list.splice(index, 1);
    } else {
        experienceConfig.responseQuestions.list.splice(index, 1);
    }
    renderExperienceConfig();
    saveAgentConfig(true);
}

function addFeedbackOption() {
    const input = document.getElementById('new-feedback-option');
    if (!input) return;
    
    const val = input.value.trim();
    if (!val) return;
    
    if (experienceConfig.feedback.options.includes(val)) {
        alert('该选项已存在');
        return;
    }
    
    experienceConfig.feedback.options.push(val);
    input.value = '';
    renderExperienceConfig();
    saveAgentConfig(true);
}

function removeFeedbackOption(index) {
    experienceConfig.feedback.options.splice(index, 1);
    renderExperienceConfig();
    saveAgentConfig(true);
}


function restoreExperienceDefaults() {
    if (confirm('确定要恢复默认配置吗？当前更改将丢失。')) {
        experienceConfig = {
            welcomeMsg: "您好！我是您的AI助手，请问有什么可以帮您？",
            welcomeQuestions: { enabled: false, list: ['如何使用这个智能体？', '你能做什么？', '给我写个代码示例'] },
            responseQuestions: { enabled: false, list: [] },
            feedback: { enabled: false, mandatory: false, custom: false, options: ['回答不准确', '回答不完整', '不符合预期'] }
        };
        renderExperienceConfig();
        saveAgentConfig(true);
        showToast('已恢复默认配置');
    }
}

// Hook into saveAgentConfig
const originalSaveAgentConfig = window.saveAgentConfig;
window.saveAgentConfig = function(silent = false) {
    // Update config from inputs
    const welcomeInput = document.getElementById('welcome-msg-input');
    if (welcomeInput) experienceConfig.welcomeMsg = welcomeInput.value;
    
    // Save to agent object
    if (currentEditorAgentId) {
        const agent = agentsData.find(a => a.id === currentEditorAgentId);
        if (agent) {
            agent.experience = JSON.parse(JSON.stringify(experienceConfig));
        }
    }
    
    if (!silent) {
        originalSaveAgentConfig();
    }
};

// Hook into initAgentEditor
const originalInitAgentEditor = window.initAgentEditor;
window.initAgentEditor = function(params) {
    originalInitAgentEditor(params);
    
    if (params && params.id) {
        const agent = agentsData.find(a => a.id == params.id);
        initExperienceConfig(agent);
    } else {
        initExperienceConfig(null);
    }
};

// Expose new functions
window.toggleExperienceFeature = toggleExperienceFeature;
window.updateQuestion = updateQuestion;
window.addQuestion = addQuestion;
window.removeQuestion = removeQuestion;
window.addFeedbackOption = addFeedbackOption;
window.removeFeedbackOption = removeFeedbackOption;
window.previewWelcomeMessage = previewWelcomeMessage;
window.restoreExperienceDefaults = restoreExperienceDefaults;
